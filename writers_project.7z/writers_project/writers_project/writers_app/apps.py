from django.apps import AppConfig


class WritersAppConfig(AppConfig):
    name = 'writers_app'
