from django.db import models

# Create your models here.
class Writer(models.Model):
    name = models.CharField(max_length=200, verbose_name="Имя писателя")
    years = models.CharField(max_length=100, verbose_name="Годы жизни")
    country = models.CharField(max_length=100, verbose_name="Страна")
    description = models.TextField(verbose_name="Описание")
    photo = models.ImageField(upload_to='writers/', blank=True, null=True, verbose_name="Фотография")
    
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name = "Писатель"
        verbose_name_plural = "Писатели"

class Book(models.Model):
    title = models.CharField(max_length=200, verbose_name="Название книги")
    author = models.ForeignKey(Writer, on_delete=models.CASCADE, verbose_name="Автор")
    year = models.IntegerField(verbose_name="Год издания")
    description = models.TextField(verbose_name="Описание")
    rating = models.FloatField(default=0.0, verbose_name="Рейтинг")
    cover = models.ImageField(upload_to='books/', blank=True, null=True, verbose_name="Обложка")
    
    def __str__(self):
        return f"{self.title} ({self.author.name})"
    
    class Meta:
        verbose_name = "Книга"
        verbose_name_plural = "Книги"