from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # 127.0.0.1:8000/
    path('writers/', views.writers_list, name='writers'),  # 127.0.0.1:8000/writers
    path('books/', views.books_list, name='books'),  # 127.0.0.1:8000/books
    path('writers/<str:writer_slug>/', views.writer_detail, name='writer_detail'),  # 127.0.0.1:8000/writers/hemingway
    path('books/<int:book_rank>/', views.book_detail, name='book_detail'),  # 127.0.0.1:8000/books/1
    path('writers/<str:writer_slug>/<str:book_slug>/', views.writer_book_detail, name='writer_book_detail'),  # 127.0.0.1:8000/writers/hemingway/the_old_man_and_the_sea
]