from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages

# Данные о писателях (временно, пока нет базы данных)
WRITERS_DATA = [
    {
        "id": 1,
        "name": "Лев Толстой",
        "slug": "tolstoy",
        "full_name": "Лев Николаевич Толстой",
        "years": "1828-1910",
        "country": "Россия",
        "description": "Один из величайших писателей мира, автор романов 'Война и мир', 'Анна Каренина'.",
        "bio": "Лев Толстой - русский писатель, мыслитель, философ и публицист. Родился в дворянской семье. Участвовал в обороне Севастополя. Позже отказался от собственности, стал вегетарианцем и критиковал государство и церковь.",
        "main_works": ["Война и мир", "Анна Каренина", "Воскресение", "Детство", "Отрочество", "Юность"],
        "birth_date": "9 сентября 1828",
        "death_date": "20 ноября 1910",
        "genres": ["Роман", "Повесть", "Рассказ", "Драма"],
        "awards": []
    },
    {
        "id": 2,
        "name": "Фёдор Достоевский",
        "slug": "dostoevsky",
        "full_name": "Фёдор Михайлович Достоевский",
        "years": "1821-1881",
        "country": "Россия",
        "description": "Классик русской литературы, мастер психологического романа.",
        "bio": "Фёдор Достоевский - один из самых значительных русских писателей. Его творчество оказало огромное влияние на мировую литературу. Пережил смертный приговор, замененный каторгой.",
        "main_works": ["Преступление и наказание", "Идиот", "Братья Карамазовы", "Униженные и оскорблённые", "Бесы"],
        "birth_date": "11 ноября 1821",
        "death_date": "9 февраля 1881",
        "genres": ["Роман", "Повесть", "Рассказ"],
        "awards": []
    },
    {
        "id": 3,
        "name": "Антон Чехов",
        "slug": "chekhov",
        "full_name": "Антон Павлович Чехов",
        "years": "1860-1904",
        "country": "Россия",
        "description": "Мастер короткого рассказа и драматург.",
        "bio": "Антон Чехов - русский писатель, прозаик, драматург. По профессии врач. Классик мировой литературы. Один из самых известных драматургов мира.",
        "main_works": ["Вишнёвый сад", "Три сестры", "Дама с собачкой", "Чайка", "Дядя Ваня", "Палата №6"],
        "birth_date": "29 января 1860",
        "death_date": "15 июля 1904",
        "genres": ["Рассказ", "Повесть", "Драма"],
        "awards": ["Пушкинская премия (1888)"]
    },
    {
        "id": 4,
        "name": "Уильям Шекспир",
        "slug": "shakespeare",
        "full_name": "Уильям Шекспир",
        "years": "1564-1616",
        "country": "Англия",
        "description": "Величайший драматург и поэт, автор множества пьес и сонетов.",
        "bio": "Уильям Шекспир - английский поэт и драматург, часто считается величайшим англоязычным писателем и одним из лучших драматургов мира. Автор около 38 пьес, 154 сонетов и других произведений.",
        "main_works": ["Гамлет", "Ромео и Джульетта", "Король Лир", "Макбет", "Отелло", "Сон в летнюю ночь"],
        "birth_date": "26 апреля 1564",
        "death_date": "23 апреля 1616",
        "genres": ["Трагедия", "Комедия", "Хроника", "Поэма"],
        "awards": []
    },
    {
        "id": 5,
        "name": "Эрнест Хемингуэй",
        "english_name": "Ernest Hemingway",
        "slug": "hemingway",
        "full_name": "Эрнест Миллер Хемингуэй",
        "years": "1899-1961",
        "country": "США",
        "description": "Лауреат Нобелевской премии по литературе, мастер лаконичного стиля.",
        "bio": "Эрнест Хемингуэй - американский писатель, журналист, лауреат Нобелевской премии по литературе 1954 года. Участник Первой и Второй мировых войн. Известен своим лаконичным стилем письма.",
        "main_works": ["Старик и море", "Прощай, оружие!", "По ком звонит колокол", "И восходит солнце", "Иметь и не иметь"],
        "birth_date": "21 июля 1899",
        "death_date": "2 июля 1961",
        "genres": ["Роман", "Рассказ", "Очерк"],
        "awards": ["Нобелевская премия по литературе (1954)", "Пулитцеровская премия (1953)"]
    },
    {
        "id": 6,
        "name": "Михаил Булгаков",
        "slug": "bulgakov",
        "full_name": "Михаил Афанасьевич Булгаков",
        "years": "1891-1940",
        "country": "Россия",
        "description": "Русский писатель, драматург, театральный режиссёр и актёр.",
        "bio": "Михаил Булгаков - русский писатель, драматург, театральный режиссёр и актёр. Автор романов, повестей, рассказов, фельетонов, пьес, инсценировок, киносценариев и оперных либретто.",
        "main_works": ["Мастер и Маргарита", "Собачье сердце", "Белая гвардия", "Театральный роман", "Бег"],
        "birth_date": "15 мая 1891",
        "death_date": "10 марта 1940",
        "genres": ["Роман", "Повесть", "Рассказ", "Драма"],
        "awards": []
    },
    {
        "id": 7,
        "name": "Джоан Роулинг",
        "slug": "rowling",
        "full_name": "Джоан Роулинг",
        "years": "род. 1965",
        "country": "Великобритания",
        "description": "Британская писательница, автор серии романов о Гарри Поттере.",
        "bio": "Джоан Роулинг — британская писательница, сценаристка и кинопродюсер, наиболее известная как автор серии романов о Гарри Поттере.",
        "main_works": ["Гарри Поттер и философский камень", "Гарри Поттер и Тайная комната", "Гарри Поттер и узник Азкабана"],
        "birth_date": "31 июля 1965",
        "death_date": "",
        "genres": ["Фэнтези", "Драма", "Детская литература"],
        "awards": ["Орден Британской империи"]
    },
    {
        "id": 8,
        "name": "Джордж Оруэлл",
        "slug": "orwell",
        "full_name": "Джордж Оруэлл",
        "years": "1903-1950",
        "country": "Великобритания",
        "description": "Британский писатель и публицист, автор антиутопических произведений.",
        "bio": "Джордж Оруэлл — британский писатель и публицист. Наиболее известен как автор культового антиутопического романа «1984» и повести «Скотный двор».",
        "main_works": ["1984", "Скотный двор", "Да здравствует фикус!"],
        "birth_date": "25 июня 1903",
        "death_date": "21 января 1950",
        "genres": ["Антиутопия", "Политическая сатира", "Документальная проза"],
        "awards": []
    },
    {
        "id": 9,
        "name": "Джейн Остин",
        "slug": "austen",
        "full_name": "Джейн Остин",
        "years": "1775-1817",
        "country": "Англия",
        "description": "Английская писательница, провозвестница реализма в британской литературе.",
        "bio": "Джейн Остин — английская писательница, провозвестница реализма в британской литературе, сатирик, писала так называемые романы нравов.",
        "main_works": ["Гордость и предубеждение", "Эмма", "Чувство и чувствительность"],
        "birth_date": "16 декабря 1775",
        "death_date": "18 июля 1817",
        "genres": ["Роман", "Комедия нравов", "Реализм"],
        "awards": []
    },
]

# Обновленные данные о книгах с добавлением book_slug
BOOKS_DATA = [
    {
        "id": 1,
        "title": "Война и мир",
        "book_slug": "war_and_peace",
        "author": "Лев Толстой",
        "author_slug": "tolstoy",
        "year": 1869,
        "rating": 4.8,
        "pages": 1225,
        "genre": ["Роман-эпопея", "Исторический роман"],
        "description": "Роман-эпопея, описывающий русское общество в эпоху войн против Наполеона. Одно из величайших произведений мировой литературы.",
        "detailed_description": """«Война и мир» — роман-эпопея Льва Толстого, описывающий русское общество в эпоху войн против Наполеона в 1805—1812 годах. Эпопея считается одним из самых значительных произведений мировой литературы. Роман включает более 500 персонажей, многие из которых являются историческими лицами."""
    },
    {
        "id": 2,
        "title": "Преступление и наказание",
        "book_slug": "crime_and_punishment",
        "author": "Фёдор Достоевский",
        "author_slug": "dostoevsky",
        "year": 1866,
        "rating": 4.7,
        "pages": 430,
        "genre": ["Психологический роман", "Философский роман"],
        "description": "Психологический роман о бывшем студенте Родионе Раскольникове, совершившем убийство.",
        "detailed_description": """«Преступление и наказание» — социально-психологический и социально-философский роман Фёдора Достоевского, над которым писатель работал в 1865—1866 годах. Впервые опубликован в 1866 году в журнале «Русский вестник». Главный герой — Родион Раскольников, бедный студент, который создаёт теорию о «праве сильной личности» и решает проверить её на себе."""
    },
    {
        "id": 3,
        "title": "Мастер и Маргарита",
        "book_slug": "the_master_and_margarita",
        "author": "Михаил Булгаков",
        "author_slug": "bulgakov",
        "year": 1967,
        "rating": 4.9,
        "pages": 480,
        "genre": ["Фантастика", "Сатира", "Философский роман"],
        "description": "Роман о визите дьявола в Москву 1930-х годов и истории о Понтии Пилате.",
        "detailed_description": """«Мастер и Маргарита» — роман Михаила Булгакова, работа над которым началась в конце 1920-х годов и продолжалась вплоть до смерти писателя. Роман является наиболее известным произведением Булгакова и одной из самых загадочных книг XX века. В романе переплетаются две сюжетные линии: история визита дьявола в Москву 1930-х годов и история о Понтии Пилате."""
    },
    {
        "id": 4,
        "title": "Гарри Поттер и философский камень",
        "book_slug": "harry_potter_and_the_philosophers_stone",
        "author": "Джоан Роулинг",
        "author_slug": "rowling",
        "year": 1997,
        "rating": 4.6,
        "pages": 320,
        "genre": ["Фэнтези", "Приключения"],
        "description": "Первая книга серии о юном волшебнике Гарри Поттере.",
        "detailed_description": """«Гарри Поттер и философский камень» — первая книга в серии романов о юном волшебнике Гарри Поттере, написанная Дж. К. Роулинг. Книга рассказывает о том, как Гарри Поттер узнает, что он волшебник, и поступает в школу магии Хогвартс."""
    },
    {
        "id": 5,
        "title": "1984",
        "book_slug": "nineteen_eighty_four",
        "author": "Джордж Оруэлл",
        "author_slug": "orwell",
        "year": 1949,
        "rating": 4.5,
        "pages": 328,
        "genre": ["Антиутопия", "Политическая фантастика"],
        "description": "Антиутопический роман о тоталитарном обществе под властью Большого Брата.",
        "detailed_description": """«1984» — роман-антиутопия Джорджа Оруэлла, изданный в 1949 году. Роман описывает тоталитарное общество, находящееся под постоянным контролем государства. Главный герой — Уинстон Смит, работник Министерства правды, который начинает сомневаться в правильности политики Партии."""
    },
    {
        "id": 6,
        "title": "Гордость и предубеждение",
        "book_slug": "pride_and_prejudice",
        "author": "Джейн Остин",
        "author_slug": "austen",
        "year": 1813,
        "rating": 4.4,
        "pages": 432,
        "genre": ["Роман", "Комедия нравов"],
        "description": "Роман о любви и социальных отношениях в английской провинции.",
        "detailed_description": """«Гордость и предубеждение» — роман Джейн Остин, который увидел свет в 1813 году. Роман рассказывает о любви и браке в аристократическом обществе Англии начала XIX века. Главные герои — Элизабет Беннет и мистер Дарси."""
    },
    {
        "id": 7,
        "title": "Старик и море",
        "book_slug": "the_old_man_and_the_sea",
        "author": "Эрнест Хемингуэй",
        "author_slug": "hemingway",
        "year": 1952,
        "rating": 4.3,
        "pages": 127,
        "genre": ["Повесть", "Притча"],
        "description": "Повесть о старом кубинском рыбаке и его борьбе с гигантской рыбой.",
        "detailed_description": """«Старик и море» — повесть Эрнеста Хемингуэя, написанная в 1952 году на Кубе и опубликованная в 1952 году. Последнее известное художественное произведение Хемингуэя, опубликованное при его жизни. Рассказывает историю старика Сантьяго, кубинского рыбака, и его борьбу с гигантской рыбой, которую он поймал в открытом море."""
    },
    {
        "id": 8,
        "title": "Гамлет",
        "book_slug": "hamlet",
        "author": "Уильям Шекспир",
        "author_slug": "shakespeare",
        "year": 1603,
        "rating": 4.7,
        "pages": 200,
        "genre": ["Трагедия", "Драма"],
        "description": "Трагедия о датском принце, мстящем за убийство отца.",
        "detailed_description": """«Гамлет» — трагедия Уильяма Шекспира в пяти актах, одна из самых известных его пьес. Написана в 1600—1601 годах. Это самая длинная пьеса Шекспира — в ней 4042 строки и 29 551 слово. Трагедия основана на легенде о датском правителе по имени Amletus, записанной датским летописцем Саксоном Грамматиком."""
    },
    {
        "id": 9,
        "title": "И восходит солнце",
        "book_slug": "the_sun_also_rises",
        "author": "Эрнест Хемингуэй",
        "author_slug": "hemingway",
        "year": 1926,
        "rating": 4.2,
        "pages": 251,
        "genre": ["Роман"],
        "description": "Роман о «потерянном поколении» после Первой мировой войны.",
        "detailed_description": """«И восходит солнце» — первый роман Эрнеста Хемингуэя, опубликованный в 1926 году. Роман посвящён «потерянному поколению» — молодым людям, прошедшим через Первую мировую войну и разочаровавшимся в послевоенном мире. Действие происходит в Париже и Испании."""
    },
    {
        "id": 10,
        "title": "Прощай, оружие!",
        "book_slug": "a_farewell_to_arms",
        "author": "Эрнест Хемингуэй",
        "author_slug": "hemingway",
        "year": 1929,
        "rating": 4.3,
        "pages": 332,
        "genre": ["Роман", "Военная проза"],
        "description": "Роман о любви на фоне Первой мировой войны.",
        "detailed_description": """«Прощай, оружие!» — роман Эрнеста Хемингуэя, вышедший в 1929 году. Роман основан на личном опыте Хемингуэя, который служил водителем санитарной машины на итальянском фронте во время Первой мировой войны. Главный герой — лейтенант Фредерик Генри, американский доброволец в итальянской армии."""
    },
    {
        "id": 11,
        "title": "По ком звонит колокол",
        "book_slug": "for_whom_the_bell_tolls",
        "author": "Эрнест Хемингуэй",
        "author_slug": "hemingway",
        "year": 1940,
        "rating": 4.4,
        "pages": 480,
        "genre": ["Роман", "Военная проза"],
        "description": "Роман о гражданской войне в Испании.",
        "detailed_description": """«По ком звонит колокол» — роман Эрнеста Хемингуэя, вышедший в 1940 году. Действие происходит во время гражданской войны в Испании в 1937 году. Главный герой — американец Роберт Джордан, который воюет на стороне республиканцев."""
    },
    {
        "id": 12,
        "title": "Ромео и Джульетта",
        "book_slug": "romeo_and_juliet",
        "author": "Уильям Шекспир",
        "author_slug": "shakespeare",
        "year": 1597,
        "rating": 4.6,
        "pages": 283,
        "genre": ["Трагедия", "Драма"],
        "description": "Трагедия о любви юноши и девушки из двух враждующих веронских родов.",
        "detailed_description": """«Ромео и Джульетта» — трагедия Уильяма Шекспира, рассказывающая о любви юноши и девушки из двух враждующих старинных родов — Монтекки и Капулетти. Сочинение обычно датируется 1594—1595 годами."""
    },
    {
        "id": 13,
        "title": "Макбет",
        "book_slug": "macbeth",
        "author": "Уильям Шекспир",
        "author_slug": "shakespeare",
        "year": 1623,
        "rating": 4.5,
        "pages": 240,
        "genre": ["Трагедия", "Драма"],
        "description": "Трагедия о шотландском генерале, который становится королём через предательство и убийство.",
        "detailed_description": """«Макбет» — трагедия Уильяма Шекспира, написанная предположительно между 1603 и 1606 годами. В основу сюжета положена хроника Рафаэла Холиншеда «История Шотландии», описывающая жизнь короля Макбета."""
    },
]
def home(request):
    """Главная страница"""
    return render(request, 'writers_app/index.html', {
        'title': 'Главная страница',
        'welcome_message': 'Добро пожаловать на сайт о писателях и книгах!'
    })

def writers_list(request):
    """Страница со списком писателей или фильтрация книг по писателю и году"""
    
    # Проверяем GET-параметры
    writer_param = request.GET.get('writers')
    year_param = request.GET.get('year')
    
    # Если есть оба параметра, выполняем фильтрацию
    if writer_param and year_param:
        # Ищем писателя по имени, английскому имени или slug
        writer = get_writer_by_name_or_slug(writer_param)
        
        if writer is None:
            messages.error(request, f'Писатель "{writer_param}" не найден.')
            return redirect('writers')
        
        # Пытаемся преобразовать год в число
        try:
            year = int(year_param)
        except ValueError:
            messages.error(request, f'Неверный формат года: {year_param}')
            return redirect('writer_detail', writer_slug=writer['slug'])
        
        # Ищем книги этого писателя за указанный год
        filtered_books = get_books_by_writer_and_year(writer['slug'], year)
        
        # Если книги не найдены, переадресуем на страницу писателя
        if not filtered_books:
            messages.error(request, f'У писателя {writer["name"]} нет книг, изданных в {year} году.')
            return redirect('writer_detail', writer_slug=writer['slug'])
        
        # Отображаем страницу с отфильтрованными книгами
        return render(request, 'writers_app/books_filtered.html', {
            'title': f'Книги {writer["name"]} за {year} год',
            'writer': writer,
            'year': year,
            'books': filtered_books,
            'writer_param': writer_param,
            'year_param': year_param
        })
    
    # Если параметров нет, показываем обычный список писателей
    # Убедимся, что у всех писателей есть slug
    for writer in WRITERS_DATA:
        if 'slug' not in writer or not writer['slug']:
            writer['slug'] = writer['name'].lower().replace(' ', '-').replace('ё', 'e')
    
    return render(request, 'writers_app/writers.html', {
        'title': 'Писатели',
        'writers': WRITERS_DATA
    })

def books_list(request):
    """Страница с топом лучших книг"""
    sorted_books = get_sorted_books()
    return render(request, 'writers_app/books.html', {
        'title': 'Топ лучших книг',
        'books': sorted_books
    })

def get_writer_by_slug(slug):
    for writer in WRITERS_DATA:
        if writer['slug'] == slug.lower():
            return writer
    return None

def writer_detail(request, writer_slug):
    """Страница с детальной информацией о писателе"""
    writer_slug = writer_slug.lower()
    writer = get_writer_by_slug(writer_slug)
    
    if writer is None:
        messages.error(request, f'Писатель "{writer_slug}" не найден.')
        return redirect('writers')
    
    # Получаем книги этого писателя из BOOKS_DATA
    writer_books = []
    for book in BOOKS_DATA:
        if book['author'].lower() == writer['name'].lower():
            writer_books.append(book)
    
    return render(request, 'writers_app/writer_detail.html', {
        'title': writer['name'],
        'writer': writer,
        'books': writer_books
    })
    
def get_sorted_books():
    """Возвращает книги, отсортированные по рейтингу (от высшего к низшему)"""
    return sorted(BOOKS_DATA, key=lambda x: x['rating'], reverse=True)

def book_detail(request, book_rank):
    """Страница с детальной информацией о книге по её месту в топе"""
    try:
        book_rank = int(book_rank)
    except ValueError:
        messages.error(request, 'Неверный номер книги.')
        return redirect('books')
    
    book = get_book_by_rank(book_rank)
    
    if book is None:
        messages.error(request, f'Книга с номером {book_rank} не найдена в топе.')
        return redirect('books')
    
    # Получаем информацию об авторе книги
    author = get_writer_by_slug(book['author_slug'])
    
    # Получаем все книги для отображения в разделе "Другие книги"
    all_books = get_sorted_books()
    
    return render(request, 'writers_app/book_detail.html', {
        'title': book['title'],
        'book': book,
        'rank': book_rank,
        'author': author,
        'books': all_books
    })
    
def get_sorted_books():
    # Возвращает книги, отсортированные по рейтингу (от высшего к низшему)
    return sorted(BOOKS_DATA, key=lambda x: x['rating'], reverse=True)

# Функция для поиска книги по месту в топе
def get_book_by_rank(rank):
    """Возвращает книгу по месту в топе (рангу)"""
    sorted_books = get_sorted_books()
    if 1 <= rank <= len(sorted_books):
        return sorted_books[rank - 1]
    return None

# Функция для поиска писателя по slug
def get_writer_by_slug(slug):
    """Поиск писателя по slug в списке WRITERS_DATA"""
    for writer in WRITERS_DATA:
        if writer.get('slug', '').lower() == slug.lower():
            return writer
    return None
    
def get_book_by_writer_and_slug(writer_slug, book_slug):
    """Поиск книги по slug писателя и slug книги"""
    for book in BOOKS_DATA:
        if (book.get('author_slug', '').lower() == writer_slug.lower() and 
            book.get('book_slug', '').lower() == book_slug.lower()):
            return book
    return None

# НОВАЯ ФУНКЦИЯ: Получение всех книг писателя
def get_books_by_writer(writer_slug):
    """Получение всех книг писателя по его slug"""
    books = []
    for book in BOOKS_DATA:
        if book.get('author_slug', '').lower() == writer_slug.lower():
            books.append(book)
    return books

def writer_book_detail(request, writer_slug, book_slug):
    """Страница с информацией о книге в разделе писателя"""
    writer_slug = writer_slug.lower()
    book_slug = book_slug.lower()
    
    # Ищем писателя
    writer = get_writer_by_slug(writer_slug)
    
    if writer is None:
        messages.error(request, f'Писатель "{writer_slug}" не найден.')
        return redirect('writers')
    
    # Ищем книгу у этого писателя
    book = get_book_by_writer_and_slug(writer_slug, book_slug)
    
    if book is None:
        messages.error(request, f'Книга "{book_slug}" не найдена у писателя {writer["name"]}.')
        return redirect('writer_detail', writer_slug=writer_slug)
    
    # Получаем все книги писателя
    writer_books = get_books_by_writer(writer_slug)
    
    return render(request, 'writers_app/writer_book_detail.html', {
        'title': f'{book["title"]} - {writer["name"]}',
        'book': book,
        'writer': writer,
        'writer_books': writer_books
    })
    
# НОВАЯ ФУНКЦИЯ: Поиск писателя по имени или slug
def get_writer_by_name_or_slug(name):
    """Поиск писателя по имени, английскому имени или slug"""
    name_lower = name.lower()
    for writer in WRITERS_DATA:
        # Проверяем имя
        if writer.get('name', '').lower() == name_lower:
            return writer
        # Проверяем английское имя (если есть)
        if writer.get('english_name', '').lower() == name_lower:
            return writer
        # Проверяем slug
        if writer.get('slug', '').lower() == name_lower:
            return writer
        # Проверяем фамилию (последнее слово в имени)
        writer_name_parts = writer.get('name', '').lower().split()
        if writer_name_parts and writer_name_parts[-1] == name_lower:
            return writer
    return None

# НОВАЯ ФУНКЦИЯ: Поиск книг по писателю и году
def get_books_by_writer_and_year(writer_slug, year):
    """Поиск книг по slug писателя и году"""
    books = []
    for book in BOOKS_DATA:
        if (book.get('author_slug', '').lower() == writer_slug.lower() and 
            book.get('year') == year):
            books.append(book)
    return books
